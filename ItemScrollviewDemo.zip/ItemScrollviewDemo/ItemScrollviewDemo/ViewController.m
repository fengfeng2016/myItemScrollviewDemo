//
//  ViewController.m
//  ItemScrollviewDemo
//
//  Created by Huarui IoT on 2018/1/25.
//  Copyright © 2018年 Huarui IoT. All rights reserved.
//

#import "ViewController.h"
#import "WJItemsControlView.h"


#define can_with [[UIScreen mainScreen] bounds].size.width / 750.0
#define can_height [[UIScreen mainScreen] bounds].size.height / 1332.0
#define Screen_With [UIScreen mainScreen].bounds.size.width
#define Screen_Hegiht [UIScreen mainScreen].bounds.size.height

#define Status_Height [UIApplication sharedApplication].statusBarFrame.size.height

#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]

#define IOS7_OR_LATER [[[UIDevice currentDevice]systemVersion] floatValue] >=7.0



@interface ViewController () <UIScrollViewDelegate>
{
    NSInteger _index ;
}


@property(strong,nonatomic) WJItemsControlView * itemControlView;


@property (nonatomic ,strong) NSArray *titleArray ;

@property (strong, nonatomic)  UIScrollView *myScrollView ;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
  
    //
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dianJi:) name:@"LoadData" object:nil] ;
    
    
    self.view.backgroundColor = [UIColor whiteColor] ;
    
    self.title = @"滑动Demo" ;
    
    self.titleArray = @[@"待处理1",@"处理中1",@"已完成1",@"已拒绝1",@"已关闭1",@"待处理2",@"处理中2",@"已完成2",@"已拒绝2",@"已关闭2"] ;
    NSArray *unSelectImaArr = @[@"aa1",@"bb1",@"cc1",@"dd1",@"ee1",@"aa1",@"bb1",@"cc1",@"dd1",@"ee1"] ;
    NSArray *selectImaArr = @[@"aa2",@"bb2",@"cc2",@"dd2",@"ee2",@"aa1",@"bb1",@"cc1",@"dd1",@"ee1"] ;
    
    self.myScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 64+110*can_height, Screen_With, Screen_Hegiht -64- (110*can_height))] ;
    
    self.myScrollView.delegate= self ;
    self.myScrollView.backgroundColor = RGBACOLOR(239, 239, 244, 1) ;
    self.myScrollView.pagingEnabled = YES ;
    
    self.myScrollView.contentSize = CGSizeMake(self.titleArray.count * Screen_With, Screen_Hegiht - 64 - (110*can_height)) ;
    
    [self.view addSubview:self.myScrollView] ;
    
    self.myScrollView.showsVerticalScrollIndicator = NO ;
    
    self.myScrollView.showsHorizontalScrollIndicator = NO ;
    
    self.myScrollView.directionalLockEnabled = YES ;
    self.automaticallyAdjustsScrollViewInsets = NO ;
    
    
    //
    
    WJItemsConfig *config = [[WJItemsConfig alloc]init] ;
    
    config.itemWidth = (Screen_With-24*2*can_with)/5.0 ;
    
    _itemControlView = [[WJItemsControlView alloc]initWithFrame:CGRectMake(24*can_with, 64 + 20*can_height, Screen_With-2*24*can_with, 70*can_height)] ;
    
    _itemControlView.tapAnimation = NO ;
    
    _itemControlView.config = config ;

    [_itemControlView setTitleArray:self.titleArray unSelectImaArr:unSelectImaArr selectImaArr:selectImaArr] ;
    
    __weak UIScrollView * weakScrollView = self.myScrollView ;
    
    [_itemControlView setTapItemWithIndex:^(NSInteger selectIndex,BOOL animation){
        
        CGFloat scrollViewW = weakScrollView.frame.size.width ;
        
        [weakScrollView scrollRectToVisible:CGRectMake(selectIndex * scrollViewW, 0.0, scrollViewW,weakScrollView.frame.size.height) animated:animation] ;
    }] ;
    
    [self.view addSubview:_itemControlView] ;
}


-(void)dianJi:(NSNotification *)notif
{
    NSInteger _currentIndex = [notif.object[@"tempIndex"] integerValue] ;
    
    NSLog(@"点击-%ld" ,_currentIndex) ;
    
    if(_currentIndex == 0)
    {
        self.view.backgroundColor = [UIColor redColor] ;
    }
    
    else if (_currentIndex == 1)
    {
        self.view.backgroundColor = [UIColor yellowColor] ;
    }
    else if (_currentIndex == 2)
    {
        self.view.backgroundColor = [UIColor blueColor] ;
    }
    else if (_currentIndex == 3)
    {
        self.view.backgroundColor = [UIColor blackColor] ;
    }
    else if (_currentIndex == 4)
    {
        self.view.backgroundColor = [UIColor brownColor] ;
    }
    else if (_currentIndex == 5)
    {
        self.view.backgroundColor = [UIColor orangeColor] ;
    }
    else if (_currentIndex == 6)
    {
        self.view.backgroundColor = [UIColor whiteColor] ;
    }
    else if (_currentIndex == 7)
    {
        
    }
    else if (_currentIndex == 8)
    {
        
    }
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    float offset = scrollView.contentOffset.x ;
    
    offset = offset/CGRectGetWidth(scrollView.frame) ;
    
    [_itemControlView moveToIndex:offset Title:@""] ;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    float offset = scrollView.contentOffset.x ;
    
    offset = offset/CGRectGetWidth(scrollView.frame) ;
    
    if((offset > 0.5) && (offset < 1))
    {
        offset = 1 ;
    }
    
    if((offset > 1.5) && (offset < 2))
    {
        offset = 2 ;
    }
    
    if ((offset > 2.5) && (offset < 3))
    {
        offset = 3 ;
    }
    
    if ((offset > 3.5) && (offset < 4))
    {
        offset = 4 ;
    }
    
    _index = offset ;
    
    [_itemControlView endMoveToIndex:offset] ;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
