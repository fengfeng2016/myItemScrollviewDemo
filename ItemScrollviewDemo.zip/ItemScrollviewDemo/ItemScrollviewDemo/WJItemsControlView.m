//
//  WJItemsControlView.m
//  SliderSegment
//
//  Created by silver on 15/11/3.
//  Copyright (c) 2015年 Fsilver. All rights reserved.
//

#import "WJItemsControlView.h"

#define can_with [[UIScreen mainScreen] bounds].size.width / 750.0
#define can_height [[UIScreen mainScreen] bounds].size.height / 1332.0
#define Screen_With [UIScreen mainScreen].bounds.size.width
#define Screen_Hegiht [UIScreen mainScreen].bounds.size.height

#define Status_Height [UIApplication sharedApplication].statusBarFrame.size.height

#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]

#define IOS7_OR_LATER [[[UIDevice currentDevice]systemVersion] floatValue] >=7.0


@implementation WJItemsConfig

-(id)init
{
    self = [super init];
    if(self){
        
        _itemWidth = 0;
        _itemFont = [UIFont systemFontOfSize:14] ;
        _textColor = RGBACOLOR(61, 66, 69, 1.0);
        _selectedColor = RGBACOLOR(255, 154, 34, 1.0);
        //        _selectedColor = [UIColor colorWithRed:61/255.0 green:209/255.0 blue:165/255.0 alpha:1];
        _linePercent = 1.0;
        _lineHieght = 1.5;
    }
    return self;
}

@end


@interface WJItemsControlView()

@property(nonatomic,strong)UIView *line;
@property(strong,nonatomic)UIView *backGroundLab;


@end


@implementation WJItemsControlView

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self){
        
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.scrollsToTop = NO;
        self.tapAnimation = YES;
        
    }
    return self;
}

-(void)setTitleArray:(NSArray *)titleArray
{
    _titleArray = titleArray;
    
    if(!_config){
        NSLog(@"请先设置config");
        return;
    }
    
    //segment
    float x = 0;
    float y = 0;
    float width = _config.itemWidth - 6;
    float height = self.frame.size.height;
    
    
    
    //分割线
    CGFloat paddingLabW = 1;
    CGFloat paddingLabH = 18;
    CGFloat paddingLabY = (height - paddingLabH)*0.5;
    
    for (int i=0; i<titleArray.count; i++) {
        
        CGFloat paddingLabX = (_config.itemWidth + 1)*i;
        
        UILabel *paddingLab = [[UILabel alloc]initWithFrame:CGRectMake(paddingLabX, paddingLabY, paddingLabW, paddingLabH)];
        paddingLab.backgroundColor = [UIColor yellowColor] ;//RGBACOLOR(201, 200, 202, 1.0);
        
        if (i > 0 && i <= titleArray.count) {
            //[self addSubview:paddingLab];
        }
        
        x = (_config.itemWidth+3)*i;
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(x, y, width, height)];
        
        [btn setTitleColor:_config.textColor forState:UIControlStateNormal];
        btn.titleLabel.font = _config.itemFont;
        
        btn.imageView.image = [UIImage imageNamed:@"屏幕快照 2015-11-27 20.02.44"];
        
        btn.tag = 100+i;
        [btn setTitle:titleArray[i] forState:UIControlStateNormal];
        
        [btn addTarget:self action:@selector(itemButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btn];
        
        if(i==0){
            
            [btn setTitleColor:_config.selectedColor forState:UIControlStateNormal];
            
            //            _currentIndex = 1;
            self.line = [[UIView alloc] initWithFrame:CGRectMake(_config.itemWidth*(1-_config.linePercent)/2.0, CGRectGetHeight(self.frame) - _config.lineHieght, _config.itemWidth*_config.linePercent, _config.lineHieght)];
            _line.backgroundColor = _config.selectedColor;
            [self addSubview:_line];
        }
        
    }
    
    self.contentSize = CGSizeMake(width*titleArray.count, height);
}

/**
 *  实现segment
 *
 *  @param titleArray     标题
 *  @param unSelectImaArr 未选中时的图片
 *  @param selectImaArr   选中时的图片
 */
-(void)setTitleArray:(NSArray *)titleArray unSelectImaArr:(NSArray*)unSelectImaArr selectImaArr:(NSArray*)selectImaArr
{
    _titleArray = titleArray;
    _unSelectImaArr = unSelectImaArr;
    _selectImaArr = selectImaArr;
    
    if(!_config){
        NSLog(@"请先设置config");
        return;
    }
    
    float x = 0;
    float y = 0;
    float width = _config.itemWidth;
    float height = self.frame.size.height;
    
    _backGroundLab = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.frame) - _config.lineHieght, self.bounds.size.width, 1.5)];
    _backGroundLab.backgroundColor = [UIColor clearColor] ;//RGBACOLOR(231, 226, 232, 1.0);
    [self addSubview:_backGroundLab];
    
    
    //分割线
    CGFloat paddingLabW = 1;
    CGFloat paddingLabH = 18;
    CGFloat paddingLabY = (height - paddingLabH)*0.5;
    
    for (int i=0; i<titleArray.count; i++) {
        
        CGFloat paddingLabX = (_config.itemWidth)*i;
        
        UILabel *paddingLab = [[UILabel alloc]initWithFrame:CGRectMake(paddingLabX, paddingLabY, paddingLabW, paddingLabH)];
        
        paddingLab.backgroundColor = [UIColor redColor] ;//RGBACOLOR(201, 200, 202, 1.0);
        
        if (i > 0 && i <= titleArray.count) {
            
            //[self addSubview:paddingLab];
        }
        
        
        x = (_config.itemWidth)*i;
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(x, y, width, height)];
        
        //设置uibutton中image 和 tittle的间距
        CGRect titleBounds = btn.titleLabel.bounds;
        CGRect imgBounds = btn.imageView.bounds;
        
        UIEdgeInsets imgInsets = UIEdgeInsetsZero;
        UIEdgeInsets titleInsets = UIEdgeInsetsZero;
        
        imgInsets.right = - titleBounds.size.width ;
        
        titleInsets.left = - imgBounds.size.width;
        
        [btn setImageEdgeInsets:imgInsets];
        [btn setTitleEdgeInsets:titleInsets];
        
        
        btn.tag = 100 + i;
        
        
        [btn setImage:[UIImage imageNamed:unSelectImaArr[i]] forState:UIControlStateNormal];
        
        [btn setTitle:titleArray[i] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:14] ;
        [btn setTitleColor:_config.textColor forState:UIControlStateNormal];
        btn.titleLabel.font = _config.itemFont;
        
        [btn addTarget:self action:@selector(itemButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btn];
        
        if(i==0){
            
            [btn setImage:[UIImage imageNamed:[selectImaArr firstObject]] forState:UIControlStateNormal];
            
            [btn setTitleColor:_config.selectedColor forState:UIControlStateNormal];
            
            //            _currentIndex = 1;
            self.line = [[UIView alloc] initWithFrame:CGRectMake(24*can_with+_config.itemWidth*(1-_config.linePercent)/2.0, 0, _config.itemWidth*_config.linePercent-48*can_with, _config.lineHieght)];
            _line.backgroundColor = _config.selectedColor;
            [_backGroundLab addSubview:_line];
        }
    }
    
    self.contentSize = CGSizeMake(width*titleArray.count, height);
}

#pragma mark - 点击事件

-(void)itemButtonClicked:(UIButton*)btn
{
    //接入外部效果
    _currentIndex = btn.tag - 100;
    
    if(_tapAnimation){
        
        //有动画，由call is scrollView 带动线条，改变颜色
        
        
    }else{
        
        //没有动画，需要手动瞬移线条，改变颜色
        [self changeItemColor:_currentIndex];
        [self changeLine:_currentIndex];
        
    }
    
    [self changeItemColor:_currentIndex];
    [self changeLine:_currentIndex];
    
    [self changeScrollOfSet:_currentIndex];
    
    [self changeImage:_currentIndex];
    
    if(self.tapItemWithIndex){
        _tapItemWithIndex(_currentIndex,_tapAnimation);
    }
    
    //点击调用
    [[NSNotificationCenter defaultCenter] postNotificationName:@"LoadData" object:@{@"tempIndex":@(_currentIndex)}] ;
}


#pragma mark - Methods

//改变文字焦点
-(void)changeItemColor:(NSInteger)index
{
    for (int i=0; i<_titleArray.count; i++) {
        
        UIButton *btn = (UIButton*)[self viewWithTag:i+100];
        
        [btn setTitleColor:_config.textColor forState:UIControlStateNormal];
        if(btn.tag == index+100){
            [btn setTitleColor:_config.selectedColor forState:UIControlStateNormal];
        }
    }
}

// 改变线条位置
-(void)changeLine:(float)index
{
    CGRect rect = _line.frame;
    rect.origin.x = 24*can_with+index*_config.itemWidth + _config.itemWidth*(1-_config.linePercent)/2.0;
    _line.frame = rect;
}

//改变选中图片
-(void)changeImage:(NSInteger)index
{
    for (int i = 0; i<self.selectImaArr.count; i++) {
        UIButton *btn = (UIButton*)[self viewWithTag:i+100];
        
        if (btn.tag == 100) {
            if (index == 0) {
                
                [btn setImage:[UIImage imageNamed:[self.selectImaArr firstObject]] forState:UIControlStateNormal];
                
            }else
            {
                [btn setImage:[UIImage imageNamed:[self.unSelectImaArr firstObject]] forState:UIControlStateNormal];
            }
            
        }else if (btn.tag == 101)
        {
            if (index == 1) {
                [btn setImage:[UIImage imageNamed:[self.selectImaArr objectAtIndex:1]] forState:UIControlStateNormal];
                
            }else
            {
                [btn setImage:[UIImage imageNamed:[self.unSelectImaArr objectAtIndex:1]] forState:UIControlStateNormal];
            }
        }else if (btn.tag == 102)
        {
            if (index == 2) {
                [btn setImage:[UIImage imageNamed:[self.selectImaArr objectAtIndex:2]] forState:UIControlStateNormal];
                
            }else
            {
                [btn setImage:[UIImage imageNamed:[self.unSelectImaArr objectAtIndex:2]] forState:UIControlStateNormal];
            }
        }
    }
}

//向上取整
- (NSInteger)changeProgressToInteger:(float)x
{
    
    float max = _titleArray.count;
    float min = 0;
    
    NSInteger index = 0;
    
    if(x< min+0.5){
        
        index = min;
        
    }else if(x >= max-0.5){
        
        index = max;
        
    }else{
        
        index = (x+0.5)/1;
    }
    
    return index;
}


//移动ScrollView
-(void)changeScrollOfSet:(NSInteger)index
{
    float  halfWidth = CGRectGetWidth(self.frame)/2.0;
    float  scrollWidth = self.contentSize.width;
    
    float leftSpace = _config.itemWidth*index - halfWidth + _config.itemWidth/2.0;
    
    if(leftSpace<0){
        leftSpace = 0;
    }
    if(leftSpace > scrollWidth- 2*halfWidth){
        leftSpace = scrollWidth-2*halfWidth;
    }
    
    [self setContentOffset:CGPointMake(leftSpace, 0) animated:YES];
}



#pragma mark - 在ScrollViewDelegate中回调
-(void)moveToIndex:(float)x Title:(NSString *)title
{
    [self changeLine:x];
    [self changeImage:x];
    NSInteger tempIndex = [self changeProgressToInteger:x];
    if(tempIndex != _currentIndex){
        //保证在一个item内滑动，只执行一次
        [self changeItemColor:tempIndex];
    }
    _currentIndex = tempIndex;
}

-(void)endMoveToIndex:(float)x
{
    [self changeLine:x];
    [self changeItemColor:x];
    [self changeImage:x];
    
    _currentIndex = x;
    
    [self changeScrollOfSet:x] ;
    
    
    if(self.f != _currentIndex)
    {
        self.f = _currentIndex ;
        
        //滚动调用
        [[NSNotificationCenter defaultCenter] postNotificationName:@"LoadData" object:@{@"tempIndex":@(_currentIndex)}] ;
    }
}





@end















































